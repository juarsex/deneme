# V14-ticketbot
Gelişmiş loglu ticket bot altyapısı
